# PyOxfordDictionary

This is a Python package that allows developers to pull data from the Oxford Dictionary API.