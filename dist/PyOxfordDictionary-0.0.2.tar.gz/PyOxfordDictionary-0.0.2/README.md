# PyOxfordDictionary

A Python Wrapper for the Oxford Dictionary API